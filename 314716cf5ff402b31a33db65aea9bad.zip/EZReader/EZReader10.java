//******************************************************************************
// E-Z Reader, version 10; (c) 2021 Erik D. Reichle, Ph.D.
// This program implements the E-Z Reader model of eye-movement control in reading.
//******************************************************************************

package ezreader10;

import java.io.*;

public class EZReader10 {
 
    // I/O file names:
    static String corpusFile;   
    static String outputFile;
    static String targetFile;

    // Model free parameters:
    static double A; 
    static double Alpha1; 
    static double Alpha2; 
    static double Alpha3; 
    static double Delta; 
    static double Epsilon;
    static double Eta1;
    static double Eta2; 
    static double I; 
    static double ITarget;
    static double Lambda; 
    static double M1;
    static double M2; 
    static double Omega1; 
    static double Omega2; 
    static double pF; 
    static double pFTarget;
    static double Psi; 
    static double S; 
    static double SigmaGamma; 
    static double V; 
    static double Xi;
    
    // Fixed simulation parameters:
    static int maxLength = 50; // = # letters + space left of word
    static int maxSentenceLength = 50; // maximum # words / sentence
    static int NSentences;
    static int NSubjects;
    
    // Display toggles:
    static boolean displayCorpus; // word IVs
    static boolean displayDists; // IOVP distributions, etc.
    static boolean displayStates; // E-Z Reader's internal states
    static boolean displayTrace; // trace of individual fixations
    static boolean displayMeans; // mean word DVs
    
    // Simulation toggles:
    static boolean includeRegressions; // include regressions?
    
    public static void main(String[] args) throws FileNotFoundException {
        
        // Start graphic user interface (GUI):
        GUIPanel gui = new GUIPanel();
        gui.displayGUI();
    }
}

//******************************************************************************