package ezreader10;

interface GUIMonitor { // Interface for handling GUI
    
    void notifyFinished();
}

//******************************************************************************