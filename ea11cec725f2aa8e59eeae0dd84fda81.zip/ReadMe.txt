RadicalLocator
==============

Author: Matthew Jones
Copyright: 2014, University of Southampton

Running the program
-------------------

This distribution requires no special installation.  Simply unzip the files to some directory on your hard drive, e.g. C:\Apps\RadicalLocator and double click the RadicalLocator.exe file to run.  Depending on your setup, you may need to be running with Administrator privileges, since it writes to a small file when quitting (containing details like the last used window position) and it therefore must have write access in order to do this.  If you have difficulty, it may be better to run the files from your 'My Documents' folder.

Disclaimer
----------

This work is provided "as is", free of charge and without any warranty, to the extent permitted by applicable law. 
The University of Southampton makes no claims as to the suitability or reliability of the software for your application. 
Under the license it is distributed under, you can redistribute the program and/or modify it as you please, but the 
University of Southampton accepts no responsibility for any damage or loss of work arising from the use of the software. 
